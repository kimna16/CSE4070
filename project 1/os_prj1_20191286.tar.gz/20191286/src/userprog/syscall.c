#include "userprog/syscall.h"
#include <stdio.h>
#include <syscall-nr.h>
#include "threads/interrupt.h"
#include "threads/thread.h"
#include "../lib/syscall-nr.h"
#include "../devices/shutdown.h"   //halt에서 shutdown하려면 필요하지 않나? 
#include "userprog/process.h"
#include "../devices/input.h"
#include "../threads/vaddr.h"

static void syscall_handler (struct intr_frame *);

void syscall_init (void) 
{
  intr_register_int (0x30, 3, INTR_ON, syscall_handler, "syscall");
}

void sys_halt(void){
    shutdown_power_off();
}
pid_t sys_exec(const char *cmd_line){
    return process_execute(cmd_line);
}
int sys_wait(pid_t wait){ 
    return process_wait(wait);
}
int sys_read(int fd, void *buffer, unsigned size){
    char* buf=buffer;
    if (fd == 0){
        unsigned i;
        for (i=0;i<size;i++){
            buf[i]=input_getc();
            if(buf[i]=='\0')
                break;
        }
        return i;
    }
    else 
        return -1;
}
int sys_write (int fd, const void *buffer, unsigned size) {
    if (fd == 1) {
        putbuf(buffer, size);
        return size;
    }
    return -1;
}
void sys_exit (int status) {
    printf("%s: exit(%d)\n", thread_name(), status);
    thread_current()->exit_status = status;
    thread_exit();
}
int sys_fibo(int n){
    int* array=(int*)malloc(sizeof(int)*(n+1));
    array[0]=0;
    array[1]=1;
    for(int i=2;i<n+1;i++){
        array[i]=array[i-1]+array[i-2];
    }
    return array[n];
}
int sys_max_of_four(int a, int b, int c, int d){
    int max=a;
    if (max<b)
        max=b;
    if (max<c)
        max=c;
    if (max<d)
        max=d;
    return max;
}

static void
syscall_handler (struct intr_frame *f UNUSED) 
{
  if(!is_user_vaddr(f->esp)) sys_exit(-1);
  int sysNum =  *(uint32_t *)(f->esp);

  switch(sysNum){
  case SYS_HALT: 
      sys_halt();
      break;
  case SYS_EXIT: 
      if(!is_user_vaddr(f->esp+4)) sys_exit(-1);
      sys_exit(*(uint32_t *)(f->esp + 4));
      break;
  case SYS_EXEC: 
      if(!is_user_vaddr(f->esp+4)) sys_exit(-1);
      f->eax=sys_exec((const char*)*(uint32_t*)(f->esp+4));
      break;
  case SYS_WAIT:
      if(!is_user_vaddr(f->esp+4)) sys_exit(-1);
      f->eax=sys_wait((pid_t)*(uint32_t*)(f->esp+4));
      break;
  case SYS_READ:
      if(!is_user_vaddr(f->esp+4)) sys_exit(-1);
      if(!is_user_vaddr(f->esp+8)) sys_exit(-1);
      if(!is_user_vaddr(f->esp+12)) sys_exit(-1);
      f->eax=sys_read((int)*(uint32_t*)(f->esp+4),(void*)*(uint32_t*)(f->esp+8),(unsigned)*(uint32_t*)(f->esp+12));
      break;
  case SYS_WRITE:
      if(!is_user_vaddr(f->esp+4)) sys_exit(-1);
      if(!is_user_vaddr(f->esp+8)) sys_exit(-1);
      if(!is_user_vaddr(f->esp+12)) sys_exit(-1);
      f->eax=sys_write((int)*(uint32_t *)(f->esp+4), (const void *)*(uint32_t *)(f->esp + 8), (unsigned)*((uint32_t *)(f->esp + 12)));
      break;
  case SYS_FIBO:
      if(!is_user_vaddr(f->esp+4)) sys_exit(-1);
      f->eax=sys_fibo(((int)*(uint32_t*)(f->esp+4)));
      break;
  case SYS_MAX_OF_FOUR:
      if (!is_user_vaddr(f->esp+4)) sys_exit(-1);
      f->eax=sys_max_of_four((int)*(uint32_t*)(f->esp+4), (int)*(uint32_t*)(f->esp+8),(int)*(uint32_t*)(f->esp+12),(int)*(uint32_t*)(f->esp+16));
      break;
  }
}
