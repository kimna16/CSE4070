#ifndef USERPROG_SYSCALL_H
#define USERPROG_SYSCALL_H
#include "../lib/user/syscall.h"

void syscall_init (void);

void sys_halt(void);
pid_t sys_exec(const char*);
int sys_wait(pid_t);
void sys_exit(int);
int sys_write(int, const void*, unsigned);
int sys_read(int, void*, unsigned);
int sys_fibo(int);
int sys_max_of_four(int,int,int,int);

#endif /* userprog/syscall.h */
