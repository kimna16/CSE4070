#include "userprog/syscall.h"
#include <stdio.h>
#include <syscall-nr.h>
#include "threads/interrupt.h"
#include "threads/thread.h"
#include "../lib/syscall-nr.h"
#include "../devices/shutdown.h"   //halt에서 shutdown하려면 필요하지 않나? 
#include "userprog/process.h"
#include "../devices/input.h"
#include "../threads/vaddr.h"
#include "../threads/synch.h"
#include "../filesys/filesys.h"
#include "../filesys/file.h"
#include "../filesys/inode.h"
#include "../filesys/directory.h"
#include <string.h>

static void syscall_handler (struct intr_frame *);
//lock은 한 번에 하나의 thread에 대해서만 owned 될 수 있어
//struct lock file_lock;

void syscall_init (void) 
{
  intr_register_int (0x30, 3, INTR_ON, syscall_handler, "syscall");
  //init lock!
  //lock_init(&file_lock);
}

void sys_halt(void){
    shutdown_power_off();
}
pid_t sys_exec(const char *cmd_line){
    //lock_acquire(&file_lock);
    //printf("////////sys_exec : %s\n", cmd_line);
    pid_t ret = process_execute(cmd_line);
    //lock_release(&file_lock);
    return ret;
}
int sys_wait(pid_t wait){ 
    return process_wait(wait);
}
int sys_read(int fd, void *buffer, unsigned size){
    if(!is_user_vaddr(buffer)) sys_exit(-1);
    char* buf=buffer;
    int ret = 0;
    if (fd == 0){
        unsigned i;
        for (i=0;i<size;i++){
            buf[i]=input_getc();
            if(buf[i]=='\0')
                break;
        }
        //lock_release(&f->inode->iLock);
        return i;
    }
    //project2에서 추가한 부분
    else{
        //struct file* f=filesys_open(fd);
        struct file* f=thread_current()->filelist[fd];
        if(f == NULL) {
            sys_exit(-1);
        }
        lock_acquire(&file_lock);
        ret = file_read(f, buffer, size);
        lock_release(&file_lock);
        return ret;
    }
    return -1;
}
int sys_write (int fd, const void *buffer, unsigned size) {
    if(!is_user_vaddr(buffer)) sys_exit(-1);
    if (fd == 1) {
        putbuf(buffer, size);
        return size;
    }
    //project2에서 추가한 부분
    else {
        struct file* f=thread_current()->filelist[fd];
        if(f == NULL){
            sys_exit(-1);
        }
        if (f->deny_write){
            return 0;
        }
        int ret = 0;
        unsigned orig=f->pos;
        while(orig < size){
            orig+=1;
        }
        lock_acquire(&file_lock);
        ret = file_write(f, buffer, size);
        //ret += orig;
        orig += ret;
        lock_release(&file_lock);
        return ret;
    }
    //return -1;
    return 0;
}
void sys_exit (int status) {
    int i;
    printf("%s: exit(%d)\n", thread_name(), status);
    thread_current()->exit_status = status;
    for(i = 3; i<128; i++){
        struct file* tmpFd = (thread_current()->filelist)[i];
        if(tmpFd != NULL){
            sys_close(i);
        }
    }
    thread_exit();
}
int sys_fibo(int n){
    int* array=(int*)malloc(sizeof(int)*(n+1));
    array[0]=0;
    array[1]=1;
    for(int i=2;i<n+1;i++){
        array[i]=array[i-1]+array[i-2];
    }
    int ret = array[n];
    free(array);
    return ret;
}
int sys_max_of_four(int a, int b, int c, int d){
    int max=a;
    if (max<b)
        max=b;
    if (max<c)
        max=c;
    if (max<d)
        max=d;
    return max;
}
bool sys_create(const char *file, unsigned initial_size){
    if (file==NULL)
        sys_exit(-1);
    //lock_acquire(&file_lock);
    int ret = filesys_create(file, initial_size);
    //lock_release(&file_lock);
    return ret;
}
bool sys_remove(const char* file){
    //printf("asdhhdisahdisahdia");
    //lock_acquire(&file_lock);
    //return filesys_remove(file);
//    printf("remove : %s\n", file);
    for(int i=3;i<128;i++){
//        printf("b");
        char*cmpName = thread_current()->filelist[i]->name;
        int j = 0;
//        for(j = 0; cmpName[j] != NULL; j++){
//            printf("name : %c\n", cmpName[j]);
//        }
//        printf("c");
        if(cmpName == NULL) continue;
//        printf("d");
        int result = strcmp(cmpName,file);
//        printf("result : %d\n", result);
        if(strcmp(cmpName,file) == 0){
            //printf("e");
            --(thread_current()->realfilenum);
            //printf("///////a\n");
            int ret = filesys_remove(file);
            //printf("////%d\n", ret);
//            lock_release(&file_lock);
            return ret;
        }
    }
//    lock_release(&file_lock);
    return false;
}
int sys_filesize(int fd){
    //struct file* f=filesys_open(fd);
    //for(int i=0;i<=fd;i++){
    //    if (i==fd && thread_current()->filelist[i]==NULL){
    //        return filesys_length(thread_current());
    //    }
    //}
    struct file* f=thread_current()->filelist[fd];
    return file_length(f);
    //return filesys_length(f);
}

//user -> entry point
//int main(){ int fd = open(NULL); }
//-> sys_open

int sys_open(const char* file){
  if(!is_user_vaddr(file)) sys_exit(-1);
  if (file==NULL)
      sys_exit(-1);
  struct file *f=filesys_open(file);
  if (f==NULL){
      return -1;
  }
  /*
  for (int i=3;i<128;i++){
      if (thread_current()->filelist[i]==NULL){
          if (strcmp(thread_current()->name, file)==0)
              file_deny_write(f);
          thread_current()->filelist[i]=f;
          lock_release(&file_lock);
          return i;
      }
  }*/
  lock_acquire(&file_lock);
  int lastindex=++(thread_current()->lastfileindex);
  //int lastindex=(thread_current()->lastfileindex);
  //for (i=3;i<=lastindex;i++){
      //if (i==lastindex){
  if (lastindex<127){        
      ++(thread_current()->realfilenum);
      if (strcmp(thread_current()->name,file)==0){
          file_deny_write(f);
      }
      thread_current()->filelist[lastindex]=f;
      strlcpy(thread_current()->filelist[lastindex]->name,file,strlen(file)+1);
      //strlen(file) + 1 을 해야 함
      lock_release(&file_lock);
      return lastindex;
  }
  else if (lastindex==127 && thread_current()->realfilenum<128){
      for(int i=127;i>=3;i--){
          if(thread_current()->filelist[i]==NULL){
              ++(thread_current()->realfilenum);
              if(strcmp(thread_current()->name,file)==0){
                  file_deny_write(f);
                }
              thread_current()->filelist[i]=f;
              strlcpy(thread_current()->filelist[i]->name,file,strlen(file)+1);
              //lock_release(&f->inode->iLock);
              lock_release(&file_lock);
              return i;
          }
      }
  }
  //lock_release(&f->inode->iLock);
  lock_release(&file_lock);
  return -1;
}
void sys_close(int fd){
    //int lastindex=thread_current()->lastfileindex;
    //struct file* f=thread_current()->filelist[lastindex];
    struct file* f=thread_current()->filelist[fd];
    if (f==NULL)
        sys_exit(-1);
    //lock_acquire(&file_lock);
    --(thread_current()->realfilenum);
    file_close(f);
    thread_current()->filelist[fd]=NULL;
    //lock_release(&file_lock);
}
void sys_seek(int fd, unsigned position){
    //int lastindex=thread_current()->lastfileindex;
    //struct file* f=thread_current()->filelist[lastindex];
    struct file* f=thread_current()->filelist[fd];
    file_seek(f, position);
}
unsigned sys_tell(int fd){
    struct file* f=thread_current()->filelist[fd];
    return file_tell(f);
}

static void
syscall_handler (struct intr_frame *f UNUSED) {
  if(!is_user_vaddr(f->esp)) sys_exit(-1);
  int sysNum =  *(uint32_t *)(f->esp);

  switch(sysNum){
  case SYS_HALT: 
      sys_halt();
      break;
  case SYS_EXIT: 
      if(!is_user_vaddr(f->esp+4)) sys_exit(-1);
      sys_exit(*(uint32_t *)(f->esp + 4));
      break;
  case SYS_EXEC: 
      if(!is_user_vaddr(f->esp+4)) sys_exit(-1);
      f->eax=sys_exec((const char*)*(uint32_t*)(f->esp+4));
      break;
  case SYS_WAIT:
      if(!is_user_vaddr(f->esp+4)) sys_exit(-1);
      f->eax=sys_wait((pid_t)*(uint32_t*)(f->esp+4));
      break;
  case SYS_READ:
      if(!is_user_vaddr(f->esp+4)) sys_exit(-1);
      if(!is_user_vaddr(f->esp+8)) sys_exit(-1);
      if(!is_user_vaddr(f->esp+12)) sys_exit(-1);
      f->eax=sys_read((int)*(uint32_t*)(f->esp+4),(void*)*(uint32_t*)(f->esp+8),(unsigned)*(uint32_t*)(f->esp+12));
      break;
  case SYS_WRITE:
      if(!is_user_vaddr(f->esp+4)) sys_exit(-1);
      if(!is_user_vaddr(f->esp+8)) sys_exit(-1);
      if(!is_user_vaddr(f->esp+12)) sys_exit(-1);
      f->eax=sys_write((int)*(uint32_t *)(f->esp+4), (const void *)*(uint32_t *)(f->esp + 8), (unsigned)*((uint32_t *)(f->esp + 12)));
      break;
  case SYS_FIBO:
      if(!is_user_vaddr(f->esp+4)) sys_exit(-1);
      f->eax=sys_fibo(((int)*(uint32_t*)(f->esp+4)));
      break;
  case SYS_MAX_OF_FOUR:
      if (!is_user_vaddr(f->esp+4)) sys_exit(-1);
      f->eax=sys_max_of_four((int)*(uint32_t*)(f->esp+4), (int)*(uint32_t*)(f->esp+8),(int)*(uint32_t*)(f->esp+12),(int)*(uint32_t*)(f->esp+16));
      break;
  case SYS_CREATE:
      if (!is_user_vaddr(f->esp+4)) sys_exit(-1);
      f->eax=sys_create((const char*)*(uint32_t*)(f->esp+4),(unsigned)*(uint32_t*)(f->esp+8));
      break;
  case SYS_REMOVE:
      if (!is_user_vaddr(f->esp+4)) sys_exit(-1);
      f->eax=sys_remove((const char*)*(uint32_t*)(f->esp+4));
      break;
  case SYS_FILESIZE:
      if (!is_user_vaddr(f->esp+4)) sys_exit(-1);
      f->eax=sys_filesize((int)*(uint32_t*)(f->esp+4));
      break;
  case SYS_OPEN:
      if (!is_user_vaddr(f->esp+4)) sys_exit(-1);
      f->eax=sys_open((const char*)*(uint32_t*)(f->esp+4));
      break;
  case SYS_CLOSE:
      if (!is_user_vaddr(f->esp+4)) sys_exit(-1);
      sys_close((int)*(uint32_t*)(f->esp+4));
      break;
  case SYS_SEEK:
      if (!is_user_vaddr(f->esp+4)) sys_exit(-1);
      sys_seek((int)*(uint32_t*)(f->esp+4),(unsigned)*(uint32_t*)(f->esp+8));
      break;
  case SYS_TELL:
      if (!is_user_vaddr(f->esp+4)) sys_exit(-1);
      f->eax=sys_tell((int)*(uint32_t*)(f->esp+4));
      break;
  }
}
