#include <stdio.h>
#include "list.h"
#include "hash.h"
#include "bitmap.h"
#include <string.h>
#include <stdlib.h>

void getLine(char* in) {
	char tmp = 0;
	int idx = 0;
	while (1) {
		scanf("%c", &tmp);
		in[idx++] = tmp;
		if (tmp == '\n') {
			in[idx - 1] = 0;
			break;
		}
	}
}

bool sortFunc(const struct list_elem* a, const struct list_elem* b, void* aux) {
	struct list_item* temp_a, * temp_b;
	temp_a = list_entry(a, struct list_item, elem);
	temp_b = list_entry(b, struct list_item, elem);
	if (temp_a->data < temp_b->data)
		return true;
	else
		return false;
}

bool uniqueFunc(const struct list_elem* a, const struct list_elem* b, void* aux) {
	struct list_item* temp_a, * temp_b;
	temp_a = list_entry(a, struct list_item, elem);
	temp_b = list_entry(b, struct list_item, elem);
	if (temp_a->data != temp_b->data)
		return true;
	else
		return false;
}

bool maxminFunc(const struct list_elem* a, const struct list_elem* b, void* aux) {
	struct list_item* temp_a, * temp_b;
	temp_a = list_entry(a, struct list_item, elem);
	temp_b = list_entry(b, struct list_item, elem);
	if (temp_a->data < temp_b->data)
		return true;
	else
		return false;
}

bool insertOrderedFunc(const struct list_elem* a, const struct list_elem* b, void* aux) {
	struct list_item* temp_a, * temp_b;
	temp_a = list_entry(a, struct list_item, elem);
	temp_b = list_entry(b, struct list_item, elem);
	if (temp_a->data < temp_b->data)
		return true;
	else
		return false;
}

bool hashLessFunc(const struct hash_elem* a, const struct hash_elem* b, void* aux) {
	struct list_item* temp_a, * temp_b;
	temp_a = list_entry(&a->list_elem, struct list_item, elem);
	temp_b = list_entry(&b->list_elem, struct list_item, elem);
	if (temp_a->data < temp_b->data)
		return true;
	else
		return false;
}

unsigned hashHashFunc(const struct hash_elem* e, void* aux) {
	struct list_item* temp = list_entry(&e->list_elem, struct list_item, elem);
	return hash_int(temp->data);
}

void hashFreeFunc(struct hash_elem* e, void* aux) {
	free(e);
}

void hashSquareFunc(struct hash_elem* e, void* aux) {
	struct list_item* temp = list_entry(&e->list_elem, struct list_item, elem);
	temp->data *= temp->data;
}

void hashTripleFunc(struct hash_elem* e, void* aux) {
	struct list_item* temp = list_entry(&e->list_elem, struct list_item, elem);
	temp->data = temp->data * temp->data * temp->data;
}

int main() {
	struct list* listArr[10] = { 0, };
	struct hash* hashArr[10] = { 0, };
	struct bitmap* bitArr[10] = { 0, };
	while (1) {
		char line[100];
		getLine(line);
		if (strcmp(line, "quit") == 0)
			break;
		char* str = strtok(line, " ");
		if (strcmp(str, "create") == 0) {
			str = strtok(NULL, " ");
			if (strcmp(str, "list") == 0) {
				str = strtok(NULL, " ");
				listArr[str[4] - '0'] = (struct list*)malloc(sizeof(struct list));
				list_init(listArr[str[4] - '0']);
			}
			else if (strcmp(str, "hashtable") == 0) {
				str = strtok(NULL, " ");
				hashArr[str[4] - '0'] = (struct hash*)malloc(sizeof(struct hash));
				hash_init(hashArr[str[4] - '0'], hashHashFunc, hashLessFunc, NULL);
			}
			else if (strcmp(str, "bitmap") == 0) {
				str = strtok(NULL, " ");
				int bitNum = str[2] - '0';
				str = strtok(NULL, " ");
				size_t size = atoi(str);
				bitArr[bitNum] = bitmap_create(size);
			}
		}
		else if (strcmp(str, "delete") == 0) {
			str = strtok(NULL, " ");
			if (str[0] == 'l') {
				free(listArr[str[4] - '0']);
			}
			else if (str[0] == 'h') {
				hash_destroy(hashArr[str[4] - '0'], hashFreeFunc);
			}
			else if (str[0] == 'b') {
				bitmap_destroy(bitArr[str[2] - '0']);
			}
		}
		else if (strcmp(str, "dumpdata") == 0) {
			str = strtok(NULL, " ");
			if (str[0] == 'l') {
				if (listArr[str[4] - '0']->head.next != &listArr[str[4] - '0']->tail) {
					struct list_elem* curr = list_begin(listArr[str[4] - '0']);
					struct list_item* temp;
					while (curr->next != NULL) {
						temp = list_entry(curr, struct list_item, elem);
						printf("%d ", temp->data);
						curr = curr->next;
					}
					printf("\n");
				}
			}
			else if (str[0] == 'h') {
				if (hashArr[str[4] - '0']->buckets->head.next != &hashArr[str[4] - '0']->buckets->tail) {
					struct hash_iterator iter;
					hash_first(&iter, hashArr[str[4] - '0']);
					struct hash_elem* curr_elem = hash_next(&iter);
					while (curr_elem != NULL) {
						curr_elem = hash_cur(&iter);
						struct list_item* temp = list_entry(&curr_elem->list_elem, struct list_item, elem);
						printf("%d ", temp->data);
						curr_elem = hash_next(&iter);
					}
					printf("\n");

				}
			}
			else if (str[0] == 'b') {
				int bitNum = str[2] - '0';
				int bitCnt = bitArr[bitNum]->bit_cnt;
				int j = 0, iter = 0;
				while (bitCnt > 0) {
					if (j >= bitCnt) {
						j = 0;
						iter++;
						bitCnt -= 32;
						break;
					}
					if ((1 << (j)) & (bitArr[bitNum]->bits[iter])) {
						printf("1");
					}
					else {
						printf("0");
					}
					j++;
				}
				printf("\n");
			}
		}
		else if (strcmp(str, "list_push_back") == 0) {
			str = strtok(NULL, " ");
			int listNum = str[4] - '0';
			str = strtok(NULL, " ");
			int temp_data = atoi(str);
			struct list_item* temp_item = (struct list_item*)malloc(sizeof(struct list_item));
			temp_item->data = temp_data;
			list_push_back(listArr[listNum], &temp_item->elem);
		}
		else if (strcmp(str, "list_push_front") == 0) {
			str = strtok(NULL, " ");
			int listNum = str[4] - '0';
			str = strtok(NULL, " ");
			int temp_data = atoi(str);
			struct list_item* temp_item = (struct list_item*)malloc(sizeof(struct list_item));
			temp_item->data = temp_data;
			list_push_front(listArr[listNum], &temp_item->elem);
		}
		else if (strcmp(str, "list_front") == 0) {
			str = strtok(NULL, " ");
			if (listArr[str[4] - '0'] != 0) {
				struct list_elem* curr = list_front(listArr[str[4] - '0']);
				struct list_item* temp = list_entry(curr, struct list_item, elem);
				printf("%d\n", temp->data);
			}
		}
		else if (strcmp(str, "list_back") == 0) {
			str = strtok(NULL, " ");
			if (listArr[str[4] - '0'] != 0) {
				struct list_elem* curr = list_back(listArr[str[4] - '0']);
				struct list_item* temp = list_entry(curr, struct list_item, elem);
				printf("%d\n", temp->data);
			}
		}
		else if (strcmp(str, "list_pop_back") == 0) {
			str = strtok(NULL, " ");
			struct list_elem* remove_elem = list_pop_back(listArr[str[4] - '0']);
		}
		else if (strcmp(str, "list_pop_front") == 0) {
			str = strtok(NULL, " ");
			struct list_elem* remove_elem = list_pop_front(listArr[str[4] - '0']);
		}
		else if (strcmp(str, "list_empty") == 0) {
			str = strtok(NULL, " ");
			int listNum = str[4] - '0';
			bool empty = list_empty(listArr[listNum]);
			if (empty)
				printf("true\n");
			else
				printf("false\n");
		}
		else if (strcmp(str, "list_size") == 0) {
			str = strtok(NULL, " ");
			int listNum = str[4] - '0';
			size_t size = list_size(listArr[listNum]);
			printf("%zu\n", size);
		}
		else if (strcmp(str, "list_max") == 0) {
			str = strtok(NULL, " ");
			int listNum = str[4] - '0';
			struct list_elem* max = list_max(listArr[listNum], maxminFunc, NULL);
			struct list_item* temp = list_entry(max, struct list_item, elem);
			printf("%d\n", temp->data);
		}
		else if (strcmp(str, "list_min") == 0) {
			str = strtok(NULL, " ");
			int listNum = str[4] - '0';
			struct list_elem* min = list_min(listArr[listNum], maxminFunc, NULL);
			struct list_item* temp = list_entry(min, struct list_item, elem);
			printf("%d\n", temp->data);
		}
		else if (strcmp(str, "list_insert") == 0) {
			str = strtok(NULL, " ");
			int listNum = str[4] - '0';
			str = strtok(NULL, " ");
			int idx = atoi(str);
			str = strtok(NULL, " ");
			int val = atoi(str);

			struct list_item* temp_item = (struct list_item*)malloc(sizeof(struct list_item));
			temp_item->data = val;

			int count = -1;
			struct list_elem* curr = list_head(listArr[listNum]);
			curr = curr->next;
			while (curr != NULL) {
				count++;
				if (count == idx) {
					if (curr == list_head(listArr[listNum])) {
						list_push_back(listArr[listNum], &temp_item->elem);
					}
					else {
						list_insert(curr, &temp_item->elem);
					}
					break;
				}
				curr = curr->next;
			}
		}
		else if (strcmp(str, "list_insert_ordered") == 0) {
			str = strtok(NULL, " ");
			int listNum = str[4] - '0';
			str = strtok(NULL, " ");
			int val = atoi(str);
			struct list_item* temp_item = (struct list_item*)malloc(sizeof(struct list_item));
			temp_item->data = val;
			list_insert_ordered(listArr[listNum], &temp_item->elem, insertOrderedFunc, NULL);
		}
		else if (strcmp(str, "list_remove") == 0) {
			str = strtok(NULL, " ");
			int listNum = str[4] - '0';
			str = strtok(NULL, " ");
			int idx = atoi(str), count = -1;
			struct list_elem* curr = list_head(listArr[listNum]), * remove_elem;
			curr = curr->next;
			while (count != idx) {
				count++;
				if (count == idx) {
					remove_elem = list_remove(curr);
				}
				curr = curr->next;
			}
		}
		else if (strcmp(str, "list_reverse") == 0) {
			str = strtok(NULL, " ");
			int listNum = str[4] - '0';
			list_reverse(listArr[listNum]);
		}
		else if (strcmp(str, "list_shuffle") == 0) {
			str = strtok(NULL, " ");
			int listNum = str[4] - '0';
			list_shuffle(listArr[listNum]);
		}
		else if (strcmp(str, "list_sort") == 0) {
			str = strtok(NULL, " ");
			int listNum = str[4] - '0';
			list_sort(listArr[listNum], sortFunc, NULL);
		}
		else if (strcmp(str, "list_splice") == 0) {
			str = strtok(NULL, " ");
			int listNum1 = str[4] - '0';
			str = strtok(NULL, " ");
			int idx1 = atoi(str);
			str = strtok(NULL, " ");
			int listNum2 = str[4] - '0';
			str = strtok(NULL, " ");
			int idx2 = atoi(str);
			str = strtok(NULL, " ");
			int idx3 = atoi(str);
			int temp;
			if (idx2 > idx3) {
				temp = idx2;
				idx2 = idx3;
				idx3 = temp;
			}
			struct list_elem* before, * first, * last, * curr = list_head(listArr[listNum1]);
			curr = curr->next;
			int count = 0;
			while (1) {
				if (count == idx1) {
					before = curr;
					break;
				}
				curr = curr->next;
				count++;
			}
			curr = list_head(listArr[listNum2]);
			curr = curr->next;
			count = 0;
			while (1) {
				if (count == idx2) {
					first = curr;
				}
				else if (count == idx3) {
					last = curr;
					break;
				}
				curr = curr->next;
				count++;
				if (curr == NULL)
					break;
			}
			list_splice(before, first, last);
		}
		else if (strcmp(str, "list_swap") == 0) {
			str = strtok(NULL, " ");
			int listNum = str[4] - '0';
			str = strtok(NULL, " ");
			int idx1 = atoi(str);
			str = strtok(NULL, " ");
			int idx2 = atoi(str), count = 0, tmp;
			if (idx2 < idx1) {
				tmp = idx2;
				idx2 = idx1;
				idx1 = tmp;
			}
			struct list_elem* curr = list_head(listArr[listNum]), * a, * b;
			curr = curr->next;
			while (1) {
				if (count == idx1) {
					a = curr;
				}
				else if (count == idx2) {
					b = curr;
					break;
				}
				curr = curr->next;
				if (!curr)
					break;
				count++;
			}
			list_swap(a, b);
		}
		else if (strcmp(str, "list_unique") == 0) {
			str = strtok(NULL, " ");
			int listNum1 = str[4] - '0';
			str = strtok(NULL, " ");
			if (str == NULL) {
				list_unique(listArr[listNum1], NULL, uniqueFunc, NULL);
			}
			else {
				int listNum2 = str[4] - '0';
				list_unique(listArr[listNum1], listArr[listNum2], uniqueFunc, NULL);
			}
		}
		else if (strcmp(str, "hash_insert") == 0) {
			str = strtok(NULL, " ");
			int hashNum = str[4] - '0';
			str = strtok(NULL, " ");
			int val = atoi(str);
			struct hash_elem* new_hash_elem = (struct hash_elem*)malloc(sizeof(struct hash_elem));
			struct list_item* new_item = list_entry(&new_hash_elem->list_elem, struct list_item, elem);
			new_item->data = val;
			struct hash_elem* checkInsertion = hash_insert(hashArr[hashNum], new_hash_elem);
		}
		else if (strcmp(str, "hash_apply") == 0) {
			str = strtok(NULL, " ");
			int hashNum = str[4] - '0';
			str = strtok(NULL, " ");
			if (strcmp(str, "square") == 0) {
				hash_apply(hashArr[hashNum], hashSquareFunc);
			}
			else if (strcmp(str, "triple") == 0) {
				hash_apply(hashArr[hashNum], hashTripleFunc);
			}
		}
		else if (strcmp(str, "hash_delete") == 0) {
			str = strtok(NULL, " ");
			int hashNum = str[4] - '0';
			str = strtok(NULL, " ");
			int val = atoi(str);
			struct hash_elem* delete_hash_elem = (struct hash_elem*)malloc(sizeof(struct hash_elem));
			struct list_item* delete_item = list_entry(&delete_hash_elem->list_elem, struct list_item, elem);
			delete_item->data = val;
			struct hash_elem* delete = hash_delete(hashArr[hashNum], delete_hash_elem);
		}
		else if (strcmp(str, "hash_empty") == 0) {
			str = strtok(NULL, " ");
			int hashNum = str[4] - '0';
			if (hash_empty(hashArr[hashNum]))
				printf("true\n");
			else
				printf("false\n");
		}
		else if (strcmp(str, "hash_size") == 0) {
			str = strtok(NULL, " ");
			int hashNum = str[4] - '0';
			size_t size = hash_size(hashArr[hashNum]);
			printf("%zu\n", size);
		}
		else if (strcmp(str, "hash_clear") == 0) {
			str = strtok(NULL, " ");
			int hashNum = str[4] - '0';
			hash_clear(hashArr[hashNum], hashFreeFunc);
		}
		else if (strcmp(str, "hash_find") == 0) {
			str = strtok(NULL, " ");
			int hashNum = str[4] - '0';
			str = strtok(NULL, " ");
			int val = atoi(str);
			struct hash_elem* find_hash_elem = (struct hash_elem*)malloc(sizeof(struct hash_elem));
			struct list_item* find_item = list_entry(&find_hash_elem->list_elem, struct list_item, elem);
			find_item->data = val;
			struct hash_elem* checkFind = hash_find(hashArr[hashNum], find_hash_elem);
			if (checkFind != NULL)
				printf("%d\n", val);
		}
		else if (strcmp(str, "hash_replace") == 0) {
			str = strtok(NULL, " ");
			int hashNum = str[4] - '0';
			str = strtok(NULL, " ");
			int val = atoi(str);
			struct hash_elem* replace_hash_elem = (struct hash_elem*)malloc(sizeof(struct hash_elem));
			struct list_item* new_item = list_entry(&replace_hash_elem->list_elem, struct list_item, elem);
			new_item->data = val;
			struct hash_elem* replace = hash_replace(hashArr[hashNum], replace_hash_elem);
		}
		else if (strcmp(str, "bitmap_all") == 0) {
			str = strtok(NULL, " ");
			int bitNum = str[2] - '0';
			str = strtok(NULL, " ");
			unsigned start = atoi(str);
			str = strtok(NULL, " ");
			unsigned cnt = atoi(str);
			if (bitmap_all(bitArr[bitNum], start, cnt))
				printf("true\n");
			else
				printf("false\n");
		}
		else if (strcmp(str, "bitmap_any") == 0) {
			str = strtok(NULL, " ");
			int bitNum = str[2] - '0';
			str = strtok(NULL, " ");
			unsigned start = atoi(str);
			str = strtok(NULL, " ");
			unsigned cnt = atoi(str);
			if (bitmap_any(bitArr[bitNum], start, cnt))
				printf("true\n");
			else
				printf("false\n");
		}
		else if (strcmp(str, "bitmap_contains") == 0) {
			str = strtok(NULL, " ");
			int bitNum = str[2] - '0';
			str = strtok(NULL, " ");
			unsigned start = atoi(str);
			str = strtok(NULL, " ");
			unsigned cnt = atoi(str);
			str = strtok(NULL, " ");
			bool check;
			if (strcmp(str, "true") == 0)
				check = bitmap_contains(bitArr[bitNum], start, cnt, 1);
			else
				check = bitmap_contains(bitArr[bitNum], start, cnt, 0);
			if (check)
				printf("true\n");
			else
				printf("false\n");
		}
		else if (strcmp(str, "bitmap_count") == 0) {
			str = strtok(NULL, " ");
			int bitNum = str[2] - '0';
			str = strtok(NULL, " ");
			unsigned start = atoi(str);
			str = strtok(NULL, " ");
			unsigned cnt = atoi(str);
			str = strtok(NULL, " ");
			size_t size;
			if (strcmp(str, "true") == 0)
				size = bitmap_count(bitArr[bitNum], start, cnt, 1);
			else
				size = bitmap_count(bitArr[bitNum], start, cnt, 0);
			printf("%zu\n", size);
		}
		else if (strcmp(str, "bitmap_dump") == 0) {
			str = strtok(NULL, " ");
			int bitNum = str[2] - '0';
			bitmap_dump(bitArr[bitNum]);
		}
		else if (strcmp(str, "bitmap_expand") == 0) {
			str = strtok(NULL, " ");
			int bitNum = str[2] - '0';
			str = strtok(NULL, " ");
			int cnt = atoi(str);
			bitArr[bitNum] = bitmap_expand(bitArr[bitNum], cnt);
		}
		else if (strcmp(str, "bitmap_flip") == 0) {
			str = strtok(NULL, " ");
			int bitNum = str[2] - '0';
			str = strtok(NULL, " ");
			unsigned idx = atoi(str);
			bitmap_flip(bitArr[bitNum], idx);
		}
		else if (strcmp(str, "bitmap_mark") == 0) {
			str = strtok(NULL, " ");
			int bitNum = str[2] - '0';
			str = strtok(NULL, " ");
			unsigned idx = atoi(str);
			bitmap_mark(bitArr[bitNum], idx);
		}
		else if (strcmp(str, "bitmap_none") == 0) {
			str = strtok(NULL, " ");
			int bitNum = str[2] - '0';
			str = strtok(NULL, " ");
			unsigned start = atoi(str);
			str = strtok(NULL, " ");
			unsigned cnt = atoi(str);
			if (bitmap_none(bitArr[bitNum], start, cnt))
				printf("true\n");
			else
				printf("false\n");
		}
		else if (strcmp(str, "bitmap_reset") == 0) {
			str = strtok(NULL, " ");
			int bitNum = str[2] - '0';
			str = strtok(NULL, " ");
			unsigned idx = atoi(str);
			bitmap_reset(bitArr[bitNum], idx);
		}
		else if (strcmp(str, "bitmap_scan_and_flip") == 0) {
			str = strtok(NULL, " ");
			int bitNum = str[2] - '0';
			str = strtok(NULL, " ");
			unsigned idx = atoi(str);
			str = strtok(NULL, " ");
			unsigned cnt = atoi(str);
			str = strtok(NULL, " ");
			size_t size;
			if (strcmp(str, "true") == 0)
				size = bitmap_scan_and_flip(bitArr[bitNum], idx, cnt, 1);
			else
				size = bitmap_scan_and_flip(bitArr[bitNum], idx, cnt, 0);
			printf("%zu\n", size);
		}
		else if (strcmp(str, "bitmap_scan") == 0) {
			str = strtok(NULL, " ");
			int bitNum = str[2] - '0';
			str = strtok(NULL, " ");
			unsigned idx = atoi(str);
			str = strtok(NULL, " ");
			unsigned cnt = atoi(str);
			str = strtok(NULL, " ");
			size_t size;
			if (strcmp(str, "true") == 0)
				size = bitmap_scan(bitArr[bitNum], idx, cnt, 1);
			else
				size = bitmap_scan(bitArr[bitNum], idx, cnt, 0);
			printf("%zu\n", size);
		}
		else if (strcmp(str, "bitmap_set_all") == 0) {
			str = strtok(NULL, " ");
			int bitNum = str[2] - '0';
			str = strtok(NULL, " ");
			if (strcmp(str, "true") == 0)
				bitmap_set_all(bitArr[bitNum], 1);
			else
				bitmap_set_all(bitArr[bitNum], 0);
		}
		else if (strcmp(str, "bitmap_set_multiple") == 0) {
			str = strtok(NULL, " ");
			int bitNum = str[2] - '0';
			str = strtok(NULL, " ");
			unsigned start = atoi(str);
			str = strtok(NULL, " ");
			unsigned cnt = atoi(str);
			str = strtok(NULL, " ");
			if (strcmp(str, "true") == 0)
				bitmap_set_multiple(bitArr[bitNum], start, cnt, 1);
			else
				bitmap_set_multiple(bitArr[bitNum], start, cnt, 0);
		}
		else if (strcmp(str, "bitmap_set") == 0) {
			str = strtok(NULL, " ");
			int bitNum = str[2] - '0';
			str = strtok(NULL, " ");
			unsigned idx = atoi(str);
			str = strtok(NULL, " ");
			if (strcmp(str, "true") == 0)
				bitmap_set(bitArr[bitNum], idx, 1);
			else
				bitmap_set(bitArr[bitNum], idx, 0);
		}
		else if (strcmp(str, "bitmap_size") == 0) {
			str = strtok(NULL, " ");
			int bitNum = str[2] - '0';
			size_t size = bitmap_size(bitArr[bitNum]);
			printf("%zu\n", size);
		}
		else if (strcmp(str, "bitmap_test") == 0) {
			str = strtok(NULL, " ");
			int bitNum = str[2] - '0';
			str = strtok(NULL, " ");
			unsigned idx = atoi(str);
			if (bitmap_test(bitArr[bitNum], idx))
				printf("true\n");
			else
				printf("false\n");
		}
	}
	return 0;
}
