#include "float_operation.h"

//int i_sub_f(int a, int b) {
//    return a*(1<<14) - b;
//}

int i_mul_f(int a, int b) {
    return a*b;
}

int f_add_i(int a, int b) {
    return a + b*(1<<14);
}

int f_div_i(int a, int b){
    return a / b;
}

//int f_add_f(int a, int b) {
//  return a + b;
//}

int f_sub_f(int a, int b) {
  return a - b;
}

int f_mul_f(int a, int b) {
  int64_t tmp = b;
  int64_t temp = tmp * a / (1<<14);
  return (int)temp;
}

int f_div_f(int a, int b) {
  int64_t tmp = a;
  int64_t temp = tmp * (1<<14) / b;
  return (int)temp;
}
