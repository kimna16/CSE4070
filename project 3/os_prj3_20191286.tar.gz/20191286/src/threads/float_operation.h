#ifndef float_c
#define float_c
#include <stdio.h>
#include <stddef.h>
#define FRACT (1 << 14)

int i_sub_i(int a, int b);

int i_mul_f(int a, int b);

int f_add_i(int a, int b);

int f_div_i(int a, int b);

int f_add_f(int a, int b) ;

int f_sub_f(int a, int b) ;

int f_mul_f(int a, int b) ;

int f_div_f(int a, int b) ;
#endif
